import '../styles/globals.css';
export const metadata = { title: 'Safety Up', description: 'Safety management and checklist platform' };
export default function RootLayout({ children }: { children: React.ReactNode; }) { return (
<html lang='en'>
<body className='bg-gray-100 text-gray-900'>
<header className='bg-white border-b'><div className='max-w-7xl mx-auto px-4 py-3 flex justify-between'><h1 className='text-xl font-semibold text-blue-700'>Safety Up</h1><nav className='space-x-4 text-sm'><a href='/dashboard'>Dashboard</a><a href='/checklists'>Checklists</a><a href='/admin'>Admin</a></nav></div></header>
<main className='max-w-7xl mx-auto p-4'>{children}</main>
</body></html> ); }